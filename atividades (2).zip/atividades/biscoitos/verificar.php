<?php 
    echo $_COOKIE['Nome'].", você nasceu na cidade de ".$_COOKIE['Cidade']." e o seu enail é ".$_COOKIE['Email'];
?>