<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    
						<form action="biscoito.php" method="POST">
				<input type="text" name = "nome" Placeholder="insira seu nome">
        <br>
					<input type="email" name = "email" Placeholder="insira seu email">
				<br>
				   <input type="text" name = "cid" Placeholder="Cidade natal">
        <br>
        
			<input type="submit" name="" value="Enviar">
    </form>
</body>
</html>